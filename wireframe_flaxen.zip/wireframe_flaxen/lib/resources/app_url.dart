
class AppUrl {

  static var baseUrl = 'https://mysoftwareoffice.com/chalo/';

  // Post Api
  static var  logInEndPoint =  'http://88.99.248.156/~anand/api/auth/login.php';

  // Post Api
  static var  signUpEndPoint = 'https://reqres.in/api/register';

  // Post Api
  static var  otpEndPoint = baseUrl + '';

  // Post Api
  static var  addAddressEndPoint = baseUrl + '';

  // Get Api
  static var  searchAtHomeEndPoint = baseUrl + '';

  // Get Api
  static var  bannerEndPoint = baseUrl + '';

  // Get Api
  static var  allCatagoriesEndPoint = baseUrl + '';

  //Get Ap i
  static var  popularVendorsEndPoint = baseUrl + '';

  // Get
  static var  searchVendorsEndPoint = baseUrl + '';

  //Get
  static var  EndPoint = baseUrl + '';




}
