class RoutesName {
  static const String start = 'Start_Screen';

  static const String hello = 'Hello_Screen';

  static const String signIn = 'SignIn_Screen';

  static const String signup = 'Signup_Screen';

  static const String verifyotp = 'Otp_Screen';

  static const String address = 'address_Screen';

  static const String navigationBar = 'Navigation_Bar';

  static const String orderHistory = 'Order_History_Screen';

  static const String home = 'Home_Screen';

  static const String afterhome = 'Sabji_Store_Screen';

  static const String orders = 'Orders_Screen';

  static const String checkout = 'Checkout_Screen';

  static const String payment = 'Payment_Screen';

  static const String paymentdone = 'Payment_Confirmation_Screen';

  static const String deliverystatus = 'Delivery_Status_Screen';

  static const String experience = 'Rating_Order_Screen';

  static const String searchscreen = 'Search_Screen';

  static const String recentorder = 'Recent_Orders_Screen';

  static const String menu = 'Menu_Screen_Screen';

  static const String wallet = 'Wallet_Screen';

  static const String about = 'About_Screen';

  static const String help = 'Help_Screen';

  static const String profile = 'Profile_Screen';
}
