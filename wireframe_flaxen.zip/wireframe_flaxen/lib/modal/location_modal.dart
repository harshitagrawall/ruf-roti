// import 'package:wireframe_flaxen/data/network/get_current_location_service.dart';
//
// class LocationModal {
//   var lattitude, longitude;
//
//   Future<void> getLocationModal() async {
//     GetLoacation location = GetLoacation();
//     await location.getCurrentLocation();
//     lattitude = location.lattitude.toString();
//     longitude = location.longitude.toString();
//   }
// }
