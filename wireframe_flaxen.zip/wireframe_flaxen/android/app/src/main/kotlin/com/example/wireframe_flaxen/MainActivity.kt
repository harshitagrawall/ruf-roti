package com.example.wireframe_flaxen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
